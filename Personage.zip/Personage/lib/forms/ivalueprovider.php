<?php

interface IValueProvider {
    public function Px_GetValue($key);
}