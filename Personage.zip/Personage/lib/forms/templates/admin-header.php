<!--Header-->
<div id="px-head" class="clear-after">
    <div class="logo">
        <?php echo $this->Px_GetImage('logo.png', THEME_NAME); ?>
    </div>
</div>
<!--End Header-->