<div class="post-content">
    <div class="quote clearfix">
        <div class="quote-symbol icon-left-quote"></div>
        <div class="quote-content">
            <blockquote><?php echo get_the_content(); ?></blockquote><span class="name"><?php the_title(); ?></span>
        </div>
    </div>
</div>